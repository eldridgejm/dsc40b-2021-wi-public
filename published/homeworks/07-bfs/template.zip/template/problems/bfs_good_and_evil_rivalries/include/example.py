{
    'OSU': 'good',
    'Michigan': 'evil',
    'USC': 'evil',
    'UCLA': 'good',
    'UCSD': 'good'
}
