def f_8(n):
i = 1
while i < n**2:
    i += 5
    for j in range(n):
        print(i, j)
