def f_7(n):
    i = 74
    while i < n:
        i *= 2
        print(i)
