def f_7(n):
    i = 100
    while i < n:
        i *= 3.1415
        print(i)
