import math
def summation(numbers):
    """Given a list, should return the sum of the numbers in the list."""
    n = len(numbers)
    if n == 0:
        return 0
    middle = math.floor(n / 2)
    return summation(numbers[:middle]) + summation(numbers[middle:])
