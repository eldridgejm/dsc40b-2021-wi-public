def bar(root):
    if root is not None:
        bar(root.left)
        print(node.key)
        bar(root.right)
